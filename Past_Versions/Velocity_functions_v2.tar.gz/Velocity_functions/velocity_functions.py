""" Doing a couple of tests with the isolated halos in ELVIS
 "" Identifying interesting velocity functions.
 ''
 "" From Shea's documentation:
 "" 1: ID of halo
 "" 2-4: XYZ in Mpc
 "" 5-7:VxVyVz in km/s
 "" 8: Vmax at z=0 in km/s
 "" 9: Vpeak
 "" 10: Virial/bound mass at z=0 in Msun
 "" 11: Mpeak
 "" 12: Rvir in kpc
 "" 13: Rmax in kpc
 "" 14: apeak
 "" 15: Mstar for G-K abundance matching, Msun
 "" 16: Mstar for Behroozi abundance matching, Msun
 "" 17: number of particles in the halo
 "" 18: parent ID (-1 for centrals)
 "" 19: ID of topmost halo in hierarchy for non-centrals
 ""
""  Annika Peter, 4/20/17
"""

"""
Aish's approach (5/15-5/16)
We can create class for each galaxy that will contain fields like ID, position, velocity, etc. Then we can reference this directory directly whenever we need this data! 
"""
# -----------------------------------IMPORTS--------------------------------------
import sys
import numpy
import random
from numpy import *
from numpy import linalg
import scipy
from scipy.optimize import brentq
import pylab as pl
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab

# -----------------------------------CLASS DEFINITIONS --------------------------------------

# A class for 3D values such as position and velocity
class ThreeDVector(object):
	def __init__(self, X, Y, Z):
		self.X = X
		self.Y = Y
		self.Z = Z
# A class for galaxies!
class Galaxy(object):
	def __init__ (self, halo, dataValues):
		self.ID = int(dataValues[0])
		self.Position = ThreeDVector(dataValues[1], dataValues[2], dataValues[3])
		self.Velocity = ThreeDVector(dataValues[4], dataValues[5], dataValues[6])
		self.Vmax = dataValues[7]
		self.Vpeak = dataValues[8]		
		self.Mvir = dataValues[9]
		self.Mpeak = dataValues[10]
		self.Rvir = dataValues[11]
		self.Rmax = dataValues[12]
		self.apeak = dataValues[13]
		self.Mstar_pref = dataValues[14]
		self.Mstar_B2013 = dataValues[15]
		self.npart = int(dataValues[16])
		self.PID = int(dataValues[17])
		self.UpID = int(dataValues[18])
		self.Satellites = []
		self.Halo = halo

# And a class for halos!
class Halo(object):
	def __init__(self, name):
		self.name = name
		self.Galaxies = []
		halo_info = read_catalog(name)
		for galaxy_info in halo_info:
			galaxy = Galaxy(self, galaxy_info)
			self.Galaxies.append(galaxy)
	def count():
		return len(self.Galaxies)


# -----------------------------------CONSTANTS--------------------------------------

# Sets a threshold for vpeak.  The catalog is mostly complete above this value.
vpeak = 12. 

# Newton's constant G in km^2 kpc/Msun*s^2 units
G = 6.67e-11 * (1.e-3)**2. * (2.e30)/(3.086e19) 

#For the first pass, I am only looking at the isolated halos.  There's no reason we can't do the same kind of analysis for the other data sets.
singleList = ['iBurr', 'iCharybdis', 'iCher', 'iDouglas', 'iHall', 'iHamilton', 'iHera', 'iKauket', 'iLincoln', 'iLouise', 'iOates', 'iOrion', 'iRemus', 'iRomulus', 'iRoy', 'iScylla', 'iSerana', 'iSiegfried', 'iSonny', 'iTaurus', 'iThelma', 'iVenus', 'iZeus'] 

#Sets the range of stellar mass to use, to identify host galaxies.  In this case, we are looking at 10^7 solar masses in stars to 3 x 10^7 solar masses.  These should really be input variables, or be used as variables once the code below is turned into a function.  But for now, I just define them here.  I am using the default relation between stellar and halo mass (Column 15, which is labeled 14 below because python uses zero offset arrays)
mstarmin1 = 1.e7
mstarmax1 = 3.e7

mstarmin2 = 1.e8
mstarmax2 = 3.e8

mstarmin3 = 1.e9
mstarmax3 = 3.e9

# -----------------------------------READ_CATALOG--------------------------------------
""" Reads a redshift catalog and returns a halo containing information about all of its galaxies """
def read_catalog(name):
	# Try opening the file
	try:
		catalog = open("ELVIS_Halo_Catalogs/"+name+".txt", "r")
		# Try reading a line
		try:
			halo_info = catalog.readlines()
			#dataList = [x.strip() for x in data]
		except Exception:
			print "Error reading file!"
	except Exception:
		print "Error opening file!"
		catalog.close()

	# Getting rid of the first three lines (comments)
	for i in range(3):
		halo_info.pop(0)
	# At this point, the list "dataList" consists of only numeric strings
	halo = []
	for data in halo_info:
		galaxy = data.split()
		galaxy_info = []
		for value in galaxy:
			galaxy_info.append(float(value))
		halo.append(galaxy_info)
	return halo
	
# -----------------------------------CREATE HALOS--------------------------------------
""" This method creates a list of halos, each halo containing a list of galaxies that belong to it """
def create_halos():
	halos = []
	for name in singleList:
		halo = Halo(name)
		halos.append(halo)
	return halos


# -----------------------------------FINDING GALAXIES IN RANGE--------------------------------------
""" This method searches all the single galaxies and returns the the ones with mstar < {mstarmax} and mstar > {mstarmin} as a list """
def find_hosts_in_range(halos, mstarmin, mstarmax):
	galaxies_in_range = []
	for halo in halos:
		for galaxy in halo.Galaxies:
			if (galaxy.PID == -1):
				if galaxy.Mstar_pref > mstarmin and galaxy.Mstar_pref < mstarmax:
					galaxies_in_range.append(galaxy)
	return galaxies_in_range

# -----------------------------------VELOCITY FUNCTION PLOT--------------------------------------
""" 
This function creates the velocity function of 2 hosts belonging to {galaxies_in_range} with mean of distribution = {mu}, std. deviation = {sigma} and saves it as {filename} 
{mass_range} is simply a string indicating the stellar mass range that is used in the title of the figure
"""
def velocityfunction(galaxies_in_range, mass_range, filename):
	random_hosts = []
	satellite_velocities = []
	i = 0
	# Finding two random, distinct hosts in {galaxies_in_range}
	for i in range(2):
		host = random.choice(galaxies_in_range)
		# If already picked this host, then pick another
		while host in random_hosts:
			host = random.choice(galaxies_in_range)
		random_hosts.append(host)
		satellite_velocities.append([])
		j = 0		
		for satellite in host.Satellites:
			satellite_velocities[i].append(satellite.Velocity.X-host.Velocity.X)
	n_bins = 20
	mu = mean(satellite_velocities[0]+satellite_velocities[1])
	sigma = std(satellite_velocities[0]+satellite_velocities[1])

	colors = ['green', 'orange']
	fig, ax = plt.subplots()
	n, bins, patches = ax.hist(satellite_velocities, n_bins, normed = 1, histtype = 'bar', color = colors, label = [random_hosts[0].Halo.name+": "+`random_hosts[0].ID`,random_hosts[1].Halo.name+": "+`random_hosts[1].ID`])
	y = mlab.normpdf(bins, mu, sigma)
	ax.plot(bins, y, '--')
	ax.set_xlabel('Vx (km/s) of satellites')
	ax.set_ylabel('Probability')
	ax.legend(prop = {'size': 10})
	ax.set_title('Velocity function of hosts in \n'+ mass_range+'\n$\mu=$'+`mu`+'; $\sigma=$'+`sigma`)
	plt.grid(True)
	fig.set_size_inches(10,10)
	#plt.show()		
	plt.savefig(filename)

	

# -----------------------------------FIND SATELLITES--------------------------------------
""" Finds the satellites of the galaxies in {galaxies_in_range} inserts them to their satellite field """
def add_satellites(galaxies_in_range):
	for host in galaxies_in_range:
		for satellite in host.Halo.Galaxies:
			if satellite.PID == host.ID:
				host.Satellites.append(satellite)

# -----------------------------------WRITE SATELLLITE INFO--------------------------------------
def satellite_info(galaxies_in_range, output_file):
	try:
		outputfile = open(output_file, "w+")
		try:
			outputfile.write("#\n#Halo\t#ID\tNo. of Satellites\tMean velocity\tStd. Deviation\n#\n")
			for host in galaxies_in_range:
				velocities = []
				mu = 0.0
				sigma = 0.0
				for satellite in host.Satellites:
					velocities.append(satellite.Velocity.X-host.Velocity.X)
				if len(velocities)>0:
					mu = mean(velocities)
					sigma = std(velocities)
				outputfile.write("{:<10}\t{:<10}\t{:<10}\t{:<10}\t{:<10}\n".format(host.Halo.name, host.ID, len(host.Satellites), mu, sigma))
					
		except Exception:
			print('Error writing to ' + output_file)
	except Exception:
		print('Error opening/creating ' + output_file)

# -----------------------------------MAIN --------------------------------------

halos = create_halos()

range1 = find_hosts_in_range(halos, mstarmin1, mstarmax1)
range2 = find_hosts_in_range(halos, mstarmin2, mstarmax2)
range3 = find_hosts_in_range(halos, mstarmin3, mstarmax3)

add_satellites(range1)
add_satellites(range2)
add_satellites(range3)

union = range1+range2+range3

#velocityfunction(range1, 'range 1 (1.e7 Msun to 3.e7 Msun)', 'range1/histogram.png')
#velocityfunction(range2, 'range 2 (1.e8 Msun to 3.e8 Msun)', 'range2/histogram.png')
#velocityfunction(range3, 'range 3 (1.e8 Msun to 3.e9 Msun)', 'range3/histogram.png')
velocityfunction(union, 'the union of all the ranges', 'stacked_histogram.png')

print "Histograms saved in the corresponding directories!"

satellite_info(range1, 'range1/satellite_info.txt')
satellite_info(range2, 'range2/satellite_info.txt')
satellite_info(range3, 'range3/satellite_info.txt')
print "Satellite data saved in the corresponding directories!"

sys.exit()


