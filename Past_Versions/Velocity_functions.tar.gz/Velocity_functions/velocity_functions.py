""" Doing a couple of tests with the isolated halos in ELVIS
 "" Identifying interesting velocity functions.
 ''
 "" From Shea's documentation:
 "" 1: ID of halo
 "" 2-4: XYZ in Mpc
 "" 5-7:VxVyVz in km/s
 "" 8: Vmax at z=0 in km/s
 "" 9: Vpeak
 "" 10: Virial/bound mass at z=0 in Msun
 "" 11: Mpeak
 "" 12: Rvir in kpc
 "" 13: Rmax in kpc
 "" 14: apeak
 "" 15: Mstar for G-K abundance matching, Msun
 "" 16: Mstar for Behroozi abundance matching, Msun
 "" 17: number of particles in the halo
 "" 18: parent ID (-1 for centrals)
 "" 19: ID of topmost halo in hierarchy for non-centrals
 ""
""  Annika Peter, 4/20/17
"""

"""
Aish's approach (5/15-5/16)
We can create class for each galaxy that will contain fields like ID, position, velocity, etc. Then we can reference this directory directly whenever we need this data! 
"""
# -----------------------------------IMPORTS--------------------------------------
import sys
import numpy
from numpy import *
from numpy import linalg
import scipy
from scipy.optimize import brentq
import pylab as pl
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab

# -----------------------------------CLASS DEFINITIONS --------------------------------------

# A class for 3D values such as position and velocity
class ThreeDVector(object):
	def __init__(self, X, Y, Z):
		self.X = X
		self.Y = Y
		self.Z = Z
# A class for galaxies!
class Galaxy(object):
	def __init__ (self, ID, Position, Velocity, Vmax, Vpeak, Mvir, Mpeak, Rvir, Rmax, apeak, Mstar_pref, Mstar_B2013, npart, PID, UpID):
		self.ID = ID
		self.Position = Position
		self.Velocity = Velocity
		self.Vmax = Vmax
		self.Vpeak = Vpeak		
		self.Mvir = Mvir
		self.Mpeak = Mpeak
		self.Rvir = Rvir
		self.Rmax = Rmax
		self.apeak = apeak
		self.Mstar_pref = Mstar_pref
		self.Mstar_B2013 = Mstar_B2013
		self.npart = npart
		self.PID = PID
		self.UpID = UpID
		self.Satellites = []

# And a class for halos!
class Halo(object):
	def __init__(self, name, filename):
		self.Name = name
		self.Galaxies = read_file(filename)

# -----------------------------------CONSTANTS--------------------------------------

# Sets a threshold for vpeak.  The catalog is mostly complete above this value.
vpeak = 12. 

# Newton's constant G in km^2 kpc/Msun*s^2 units
G = 6.67e-11 * (1.e-3)**2. * (2.e30)/(3.086e19) 

#For the first pass, I am only looking at the isolated halos.  There's no reason we can't do the same kind of analysis for the other data sets.
singleList = ['iBurr', 'iCharybdis', 'iCher', 'iDouglas', 'iHall', 'iHamilton', 'iHera', 'iKauket', 'iLincoln', 'iLouise', 'iOates', 'iOrion', 'iRemus', 'iRomulus', 'iRoy', 'iScylla', 'iSerana', 'iSiegfried', 'iSonny', 'iTaurus', 'iThelma', 'iVenus', 'iZeus'] 

#Sets the range of stellar mass to use, to identify host galaxies.  In this case, we are looking at 10^7 solar masses in stars to 3 x 10^7 solar masses.  These should really be input variables, or be used as variables once the code below is turned into a function.  But for now, I just define them here.  I am using the default relation between stellar and halo mass (Column 15, which is labeled 14 below because python uses zero offset arrays)
mstarmin1 = 1.e7
mstarmax1 = 3.e7

mstarmin2 = 1.e8
mstarmax2 = 3.e8

mstarmin3 = 1.e9
mstarmax3 = 3.e9



# -----------------------------------READING THE FILE--------------------------------------
""" This method will read a redshift zero catalog of a halo and create a list of galaxies belonging to that halo """
def read_file (filename):
	galaxyList = []
	# Try opening the file
	try:
		dataFile = open(filename, "r")
		# Try reading a line
		try:
			dataList = dataFile.readlines()
			#dataList = [x.strip() for x in data]
		except Exception:
			print "Error reading file!"
	except Exception:
		print "Error opening file!"
		dataFile.close()

	# Getting rid of the first three lines (comments)
	for i in range(3):
		dataList.pop(0)
	# At this point, the list "dataList" consists of only numeric strings

	for data in dataList:
		dataValuesString = data.split()
		dataValues = []
		for attribute in dataValuesString:
			dataValues.append(float(attribute))
		galaxy = Galaxy(dataValues[0],ThreeDVector(dataValues[1], dataValues[2], dataValues[3]),ThreeDVector(dataValues[4], dataValues[5], dataValues[6]),dataValues[7],dataValues[8],dataValues[9],dataValues[10],dataValues[11],dataValues[12],dataValues[13],dataValues[14],dataValues[15],dataValues[16],dataValues[17],dataValues[18])
		galaxyList.append(galaxy)
	

	# At this point, galaxyList is full of galaxy objects containing data in numeric form
	# Cleaning up a bit..
	for galaxy in galaxyList:
		galaxy.ID = int(galaxy.ID)
		galaxy.npart = int(galaxy.npart)
		galaxy.PID = int(galaxy.PID)
		galaxy.UpID = int(galaxy.UpID)

	# galaxyList is now ready!
	return galaxyList
# -----------------------------------CREATE HALOS--------------------------------------
""" This method creates a list of halos, each halo containing a list of galaxies that belong to it """
def create_halos():
	halos = []
	for single in singleList:
		filename = "ELVIS_Halo_Catalogs/"+single+".txt"
		halo = Halo(single, filename)
		halos.append(halo)
	return halos
# -----------------------------------COUNT SINGLE GALAXIES --------------------------------------
""" This method counts and returns the number of single galaxies across all halos """
def count_galaxies(halos):
	count = 0
	for halo in halos:
		count += len(halo.Galaxies)	
	return count

# -----------------------------------FINDING GALAXIES IN RANGE--------------------------------------
""" This method searches all the single galaxies and returns the the ones with mstar < {mstarmax} and mstar > {mstarmin} as a list """
def find_hosts_in_range(halos, mstarmin, mstarmax):
	galaxies_in_range = []
	for halo in halos:
		for galaxy in halo.Galaxies:
			if (galaxy.PID == -1):
				if galaxy.Mstar_pref > mstarmin and galaxy.Mstar_pref < mstarmax:
					galaxies_in_range.append(galaxy)
	return galaxies_in_range

# -----------------------------------VELOCITY FUNCTION PLOT--------------------------------------
""" 
This function creates the velocity function of hosts belonging to {galaxies_in_range} with mean of distribution = {mu}, std. deviation = {sigma} and saves it as {filename} 
{mass_range} is simply a string indicating the stellar mass range that is used in the title of the figure
"""
def velocityfunction(galaxies_in_range, mu, sigma, num_of_bins, mass_range, filename):
	velocities_in_range = []
	for galaxy in galaxies_in_range:
		velocities_in_range.append(galaxy.Velocity.X)
	n, bins, patches = plt.hist(velocities_in_range, num_of_bins, normed = 1)
	y = mlab.normpdf(bins, mu, sigma)
	plt.plot(bins,y,'--')
	plt.xlabel('Vx (km/s)')
	plt.ylabel('Probability')
	plt.title('Velocity function for individual hosts with mass between\n'+ mass_range+' $\mu=$'+`mu`+'; $\sigma=$'+`sigma`)
	plt.grid(True)
	plt.savefig(filename)
	plt.clf()
# -----------------------------------FIND SATELLITES--------------------------------------
"""
Finds the satellites of the galaxies in {galaxies_in_range} inserts them to their satellite field
"""
def add_satellites(halos, galaxies_in_range):
	for halo in halos:
		for satellite in halo.Galaxies:
			for host in galaxies_in_range:
				if satellite.PID == host.ID:
					host.Satellites.append(satellite)

def count_satellite(galaxies_in_range, output_file):
	try:
		outputfile = open(output_file, "w+")
		try:
			outputfile.write("#Number of satellites of hosts belonging to range1\n#ID\tNo. of Satellites\n#\n")
			for galaxy in galaxies_in_range:
				outputfile.write(`galaxy.ID` + " "+ `len(galaxy.Satellites)`+"\n")
		except Exception:
			print('Error writing to ' + output_file)
	except Exception:
		print('Error opening/creating ' + output_file)

# -----------------------------------MAIN --------------------------------------
halos = create_halos()
			
range1 = find_hosts_in_range(halos, mstarmin1, mstarmax1)
range2 = find_hosts_in_range(halos, mstarmin2, mstarmax2)
range3 = find_hosts_in_range(halos, mstarmin3, mstarmax3)


print "Total number of single galaxies: " + `count_galaxies(halos)`

add_satellites(halos, range1)
add_satellites(halos, range2)
add_satellites(halos, range3)

velocityfunction(range1, 45, 50, 20, '1.e7 and 3.e7', 'range1/histogram.png')
velocityfunction(range2, 20, 50, 20, '1.e8 and 3.e8', 'range2/histogram.png')
velocityfunction(range3, -10, 21, 20, '1.e8 and 3.e9', 'range3/histogram.png')
print "Histograms saved in the corresponding directories!"

count_satellite(range1, 'range1/satellite_count.txt')
count_satellite(range2, 'range2/satellite_count.txt')
count_satellite(range3, 'range3/satellite_count.txt')
print "Satellite count data saved in the corresponding directories!"


