To create the velocity function histograms of each stellar mass range, run the "velocity_functions.py" python file. 
The histogram will be saved in the corresponding "range" folder. Along with the histogram, the program also creates a text file in each folder that contains the ID of each galaxy in the range along with the number of satellites it has.
