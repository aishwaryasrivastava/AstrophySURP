""" Doing a couple of tests with the isolated halos in ELVIS
 "" Identifying interesting velocity functions.
 ''
 "" From Shea's documentation:
 "" 1: ID of halo
 "" 2-4: XYZ in Mpc
 "" 5-7:VxVyVz in km/s
 "" 8: Vmax at z=0 in km/s
 "" 9: Vpeak
 "" 10: Virial/bound mass at z=0 in Msun
 "" 11: Mpeak
 "" 12: Rvir in kpc
 "" 13: Rmax in kpc
 "" 14: apeak
 "" 15: Mstar for G-K abundance matching, Msun
 "" 16: Mstar for Behroozi abundance matching, Msun
 "" 17: number of particles in the halo
 "" 18: parent ID (-1 for centrals)
 "" 19: ID of topmost halo in hierarchy for non-centrals
 ""
""  Annika Peter, 4/20/17
"""

# -----------------------------------IMPORTS--------------------------------------

import sys
import numpy
import random
from numpy import * 
from numpy import linalg
import scipy
from scipy.optimize import brentq
import pylab as pl
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import numpy as np
np.seterr(divide = 'ignore', invalid = 'ignore')

# -----------------------------------CLASS DEFINITIONS --------------------------------------

# A class for 3D values such as position and velocity
class ThreeDVector(object):
	def __init__(self, X, Y, Z):
		self.X = X
		self.Y = Y
		self.Z = Z
# A class for galaxies!
class Galaxy(object):
	def __init__ (self, halo, dataValues):
		self.ID = int(dataValues[0])
		self.Position = ThreeDVector(dataValues[1], dataValues[2], dataValues[3])
		self.Velocity = ThreeDVector(dataValues[4], dataValues[5], dataValues[6])
		self.Vmax = dataValues[7]
		self.Vpeak = dataValues[8]		
		self.Mvir = dataValues[9]
		self.Mpeak = dataValues[10]
		self.Rvir = dataValues[11]
		self.Rmax = dataValues[12]
		self.apeak = dataValues[13]
		self.Mstar_pref = dataValues[14]
		self.Mstar_B2013 = dataValues[15]
		self.npart = int(dataValues[16])
		self.PID = int(dataValues[17])
		self.UpID = int(dataValues[18])
		self.Satellites = []
		self.Halo = halo

# And a class for halos!
class Halo(object):
	def __init__(self, name):
		self.name = name
		self.Galaxies = []
		halo_info = read_catalog(name)
		for galaxy_info in halo_info:
			galaxy = Galaxy(self, galaxy_info)
			self.Galaxies.append(galaxy)
	def count():
		return len(self.Galaxies)


# -----------------------------------CONSTANTS--------------------------------------

# Sets a threshold for vpeak.  The catalog is mostly complete above this value.
vpeak = 12. 

# Newton's constant G in km^2 kpc/Msun*s^2 units
G = 6.67e-11 * (1.e-3)**2. * (2.e30)/(3.086e19) 

#For the first pass, I am only looking at the isolated halos.  There's no reason we can't do the same kind of analysis for the other data sets.
singleList = ['iBurr', 'iCharybdis', 'iCher', 'iDouglas', 'iHall', 'iHamilton', 'iHera', 'iKauket', 'iLincoln', 'iLouise', 'iOates', 'iOrion', 'iRemus', 'iRomulus', 'iRoy', 'iScylla', 'iSerana', 'iSiegfried', 'iSonny', 'iTaurus', 'iThelma', 'iVenus', 'iZeus'] 
pairedList = ['Kauket&Kek','Lincoln&Douglas','Romulus&Remus', 'Siegfried&Roy', 'Taurus&Orion','Thelma&Louise','Venus&Serana','Zeus&Hera']
#Sets the range of stellar mass to use, to identify host galaxies.  In this case, we are looking at 10^7 solar masses in stars to 3 x 10^7 solar masses.  These should really be input variables, or be used as variables once the code below is turned into a function.  But for now, I just define them here.  I am using the default relation between stellar and halo mass (Column 15, which is labeled 14 below because python uses zero offset arrays)

mstarmin_values = [1.e7, 1.e8, 1.e9]
mstarmax_values = [3.e7, 3.e8, 3.e9]

# -----------------------------------READ_CATALOG--------------------------------------
""" Reads a redshift catalog and returns a list of values for each galaxy """
def read_catalog(name):
	# Try opening the file
	try:
		catalog = open("../ELVIS_Halo_Catalogs/"+name+".txt", "r")
		# Try reading a line
		try:
			lines = catalog.readlines()
		except Exception:
			print "Error reading file!"
		catalog.close()
	except Exception:
		print "Error opening file!"
		

	# Getting rid of the first three lines (comments)
	for i in range(3):
		lines.pop(0)
	# At this point, the list "dataList" consists of only numeric strings
	# {halo} is simply a list of data values for each galaxy
	halo = []
	for line in lines:
		galaxy_info = line.split()
		i = 0
		for i in range(len(galaxy_info)):	
			galaxy_info[i] = float(galaxy_info[i])
		halo.append(galaxy_info)
	return halo
	
# -----------------------------------CREATE HALOS--------------------------------------
""" This method creates a list of halos, each halo containing a list of galaxies that belong to it """
def create_halos(name_list):
	halos = []
	for name in name_list:
		halo = Halo(name)
		halos.append(halo)
	return halos


# -----------------------------------FINDING GALAXIES IN RANGE--------------------------------------
""" This method searches all the single galaxies and returns the the ones with mstar < {mstarmax} and mstar > {mstarmin} as a list """
def find_hosts_in_range(halos, rangeno):
	galaxies_in_range = []
	for halo in halos:
		for galaxy in halo.Galaxies:
			if (galaxy.PID == -1):
				if galaxy.Mstar_pref > mstarmin_values[rangeno-1] and galaxy.Mstar_pref < mstarmax_values[rangeno-1]:
					galaxies_in_range.append(galaxy)
	return galaxies_in_range

# -----------------------------------VELOCITY FUNCTION--------------------------------------
""" This function creates the velocity function of 2 hosts belonging to {galaxies_in_range} with mean of distribution = {mu}, std. deviation = {sigma} and saves it as {filename} """
def velocity_function(galaxies_in_range, rangeindex, stacked):
	filename = ""
	title = ""
	random_hosts = []
	velocities = []
	i = 0
	# Finding two random, distinct hosts in {galaxies_in_range}
	for i in range(2):
		host = random.choice(galaxies_in_range)
		# If already picked this host, then pick another
		while host in random_hosts:
			host = random.choice(galaxies_in_range)
		random_hosts.append(host)
		velocities.append(satellite_velocities(host))
	n_bins = 20
	mu = mean(velocities[0]+velocities[1])
	sigma = std(velocities[0]+velocities[1])
	fig, ax = plt.subplots()
	n, bins, patches = ax.hist(velocities, n_bins, normed = 1, histtype = 'bar', label = [random_hosts[0].Halo.name+": "+`random_hosts[0].ID`,random_hosts[1].Halo.name+": "+`random_hosts[1].ID`])
	y = mlab.normpdf(bins, mu, sigma)
	ax.plot(bins, y, '--')
	ax.set_xlabel('Vx (km/s) of satellites')
	ax.set_ylabel('Probability')
	ax.legend(prop = {'size': 10})
	plt.grid(True)
	fig.set_size_inches(10,10)

	if not stacked:
		filename = "Range{i1}/range{i2}_velocity_function.png".format(i1 = rangeindex, i2 = rangeindex)

		title = "Velocity function of hosts in range {index} ({mstarminvalue} Msun to {mstarmaxvalue} Msun)\n$\mu =$ {mean}, $\sigma =$ {std}".format(index = "1, 2, and 3", mstarminvalue = mstarmin_values[rangeindex-1], mstarmaxvalue = mstarmax_values[rangeindex-1], mean = mu, std = sigma)
	else:
		filename = "stacked_velocity_function.png"
		title = "Velocity function of hosts in ranges 1, 2 and 3 \n$\mu =$ {mean}, $\sigma =$ {std}".format(mean = mu, std = sigma)

	ax.set_title(title)
	plt.savefig(filename)

# -----------------------------------VELOCITY FUNCTION BY RANGE-----------------------------
""" This function creates a comparison of the satellite velocities of the three different ranges """
def velocity_function_by_range(galaxies):
	# {velocities} is a list (size 3), each element is a list of satellite velocities of the respective range 
	velocities = []
	i = 0
	for i in range(3):
		velocities.append([])
		for host in galaxies[i]:
			velocities[i]+=(satellite_velocities(host))
	filename = "satellite_velocity_function_by_range.png"
	mu = mean(velocities[0]+velocities[1]+velocities[2])
	sigma = std(velocities[0]+velocities[1]+velocities[2])
	fig, ax = plt.subplots()
	n_bins = 20
	n, bins, patches = ax.hist(velocities, n_bins, normed = 1, histtype = 'stepfilled', stacked = True, label = ["Range 1", "Range 2", "Range 3"])
	y = mlab.normpdf(bins, mu, sigma)
	ax.plot(bins, y, '--')
	ax.set_xlabel('Vx (km/s) of satellites')
	ax.set_ylabel('Probability')
	ax.legend(prop = {'size': 10})
	ax.set_title('Velocity function of satellites in different stellar mass ranges\n$\mu =$ {mean} $\sigma =$ {std}'.format(mean = mu, std = sigma))
	plt.grid(True)
	fig.set_size_inches(10,10)	
	plt.savefig(filename)

# -----------------------------------SATELLITE VELOCITY--------------------------------------
def satellite_velocities(host):
	velocities = []
	for satellite in host.Satellites:
		velocities.append(satellite.Velocity.X - host.Velocity.X)
	return velocities

# -----------------------------------FIND SATELLITES--------------------------------------
""" Finds the satellites of the galaxies in {galaxies_in_range} inserts them to their satellite field """
def find_satellites(galaxies_in_range):
	for host in galaxies_in_range:
		for satellite in host.Halo.Galaxies:
			if satellite.PID == host.ID:
				host.Satellites.append(satellite)

# -----------------------------------WRITE SATELLITE DATA--------------------------------------
""" Creates a text file and writes satellite data for {galaxies_in_range} to it """
def get_satellite_data(galaxies_in_range, rangeindex):
	filename = "Range{i1}/range{i2}_satellite_info.txt".format(i1 = rangeindex, i2 = rangeindex)
	try:
		outputfile = open(filename, "w+")
		try:
			outputfile.write("#\n{:<10}\t{:<10}\t{:<10}\t{:<10}\t{:<10}\n#".format("# Halo", "Host ID", "#Satellites", "Mean Vx (km/s)", "Std. Deviation of Vx (km/s)"))
			for host in galaxies_in_range:
				mu = 0.0
				sigma = 0.0
				velocities = satellite_velocities(host)
				if len(velocities)>0:
					mu = mean(velocities)
					sigma = std(velocities)
					#todo - mean of sat velocities
				outputfile.write("\n{:<10}\t{:<10}\t{:<10}\t{:<10}\t{:<10}".format(host.Halo.name, host.ID, len(host.Satellites), mu, sigma))
					
		except Exception:
			print('Error writing to ' + filename)
	except Exception:
		print('Error opening/creating ' + filename)

# -----------------------------------CUT VELOCITY FUNCTION BY MASS--------------------------------------
""" Creates a velocity function of {galaxies} cut by mass (mstar > cutoffmass and mass < cutoffmass) """
def velocity_function_mstar_cut(galaxies, cutoffmass, rangeindex):
	filename = "Range{i1}/range{i2}_velocity_function_cut_by_mass.png".format(i1 = rangeindex, i2 = rangeindex)
	little = []
	big = []
	for host in galaxies:
		for satellite in host.Satellites:
			if satellite.Mstar_pref < cutoffmass:
				little.append(satellite.Velocity.X - host.Velocity.X)
			else:
				big.append(satellite.Velocity.X - host.Velocity.X)
	mu = mean(little+big)
	sigma = std(little+big)
	fig, ax = plt.subplots()
	n_bins = 20
	n, bins, patches = ax.hist([little, big], n_bins, normed = 1, histtype = 'bar', label = ["Msun < "+'%.2e' % cutoffmass, "Msun > "+'%.2e' % cutoffmass])
	y = mlab.normpdf(bins, mu, sigma)
	ax.plot(bins, y, '--')
	ax.set_xlabel('Vx (km/s) of satellites')
	ax.set_ylabel('Probability')
	ax.legend(prop = {'size': 10})
	ax.set_title("Range {galaxy_range}: Comparison of velocity functions of satellites of big and little hosts\n(cutoff = {cutoff} Msun) $\mu$ = {mu} $\sigma$ = {sigma}".format(galaxy_range = rangeindex, cutoff = cutoffmass, mu = mu, sigma = sigma))
	plt.grid(True)
	fig.set_size_inches(10,10)		
	plt.savefig(filename)

# -----------------------------------CUT VELOCITY FUNCTION BY PEAK SCALE FACTOR--------------------------------------
""" Creates a text file and writes satellite data cut by apeak (apeak < cutoff apeak > cutoff) """
def satellite_data_apeak_cut(galaxies, cutoffapeak, rangeindex):
	below_cutoff_filename = "Range{i1}/range{i2}_satellites_below_{cutoff}_apeak.txt".format(i1 = rangeindex, i2 = rangeindex, cutoff = cutoffapeak)
	above_cutoff_filename = "Range{i1}/range{i2}_satellites_above_{cutoff}_apeak.txt".format(i1 = rangeindex, i2 = rangeindex, cutoff = cutoffapeak)
	try:
		below_cutoff_file = open(below_cutoff_filename, "w+")
		above_cutoff_file = open(above_cutoff_filename, "w+")
		try:	
			below_cutoff_file.write("#\n#{:<10}\t{:<10}\t{:<10}\t{:<10}\n#".format("Halo", "Host ID", "Satellite ID", "Satellite apeak"))	
			above_cutoff_file.write("#\n#{:<10}\t{:<10}\t{:<10}\t{:<10}\n#".format("Halo", "Host ID", "Satellite ID", "Satellite apeak"))	
			for host in galaxies:
				for satellite in host.Satellites:
					if satellite.apeak < cutoffapeak:
						below_cutoff_file.write("\n{:<10}\t{:<10}\t{:<10}\t{:<10}".format(host.Halo.name, host.ID, satellite.ID, satellite.apeak))	
					else:
						above_cutoff_file.write("\n{:<10}\t{:<10}\t{:<10}\t{:<10}".format(host.Halo.name, host.ID, satellite.ID, satellite.apeak))
					
		except Exception:
			print('Error writing to apeak cutoff files')
	except Exception:
		print('Error opening/creating apeak cutoff files')

# -----------------------------------GENERATE DATA --------------------------------------
def generate_data(halos, directory):
	ranges = []
	for i in range(1,4):

		mstarmin = mstarmin_values[i-1]
		mstarmax = mstarmax_values[i-1]

		print "\n\tFinding galaxies in range "+`i`
		galaxies_in_range = find_hosts_in_range(halos, i)

		find_satellites(galaxies_in_range)
		
		get_satellite_data(galaxies_in_range, i)

		velocity_function(galaxies_in_range, i, stacked = False)

		velocity_function_mstar_cut(galaxies_in_range, 1.e5, i)

		satellite_data_apeak_cut(galaxies_in_range, 0.5, i)
	
		ranges.append(galaxies_in_range)

	velocity_function(ranges[0]+ranges[1]+ranges[2], 0, stacked = True)

	velocity_function_by_range(ranges, directory)
	
# -----------------------------------MAIN --------------------------------------
List = singleList+pairedList

halos = create_halos(List)

print "Generating data..."
generate_data(halos, "")

print "\nDone! Saved all files."
sys.exit()


